-- begin common tables
CREATE TABLE [dbo].[category] (
	[game] [tinyint] NOT NULL ,
	[code] [tinyint] NOT NULL ,
	[name] [nvarchar] (20) COLLATE Korean_Wansung_CI_AS NOT NULL ,
	[deleted] [bit] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[game_title] (
	[code] [tinyint] NOT NULL ,
	[name] [nvarchar] (20) NOT NULL ,
	[table_prefix] [varchar] (20) NOT NULL ,
	[auth_id] [tinyint] NOT NULL ,
	[email] [varchar] (50) NOT NULL 	 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[open_petition] (
	[seq] [char] (14) NOT NULL ,
	[game] [tinyint] NOT NULL ,
	[world] [tinyint] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[state] (
	[code] [tinyint] NOT NULL ,
	[name] [nvarchar] (20) NOT NULL ,
	[opened] [bit] NOT NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[category] WITH NOCHECK ADD 
	CONSTRAINT [PK_category] PRIMARY KEY  CLUSTERED 
	(
		[game],
		[code]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[category] WITH NOCHECK ADD 
	CONSTRAINT [DF_category_deleted] DEFAULT (0) FOR [deleted]
GO

ALTER TABLE [dbo].[game_title] WITH NOCHECK ADD 
	CONSTRAINT [PK_game_title] PRIMARY KEY  CLUSTERED 
	(
		[code]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[state] WITH NOCHECK ADD 
	CONSTRAINT [PK_state] PRIMARY KEY  CLUSTERED 
	(
		[code]
	)  ON [PRIMARY] 
GO

 CREATE  CLUSTERED  INDEX [IX_open_petition_gw] ON [dbo].[open_petition]([game], [world]) ON [PRIMARY]
GO

-- end common tables

-- begin inserting system data
INSERT state (code, name, opened) VALUES (2, '����', 1)
INSERT state (code, name, opened) VALUES (3, 'üũ�ƿ�', 1)
INSERT state (code, name, opened) VALUES (4, '�����', 1)
INSERT state (code, name, opened) VALUES (5, '������û', 1)
INSERT state (code, name, opened) VALUES (6, '��������', 0)
INSERT state (code, name, opened) VALUES (7, '����', 1)
INSERT state (code, name, opened) VALUES (8, '�����̰�', 0)
INSERT state (code, name, opened) VALUES (9, '�޽����Ϸ�', 0)
INSERT state (code, name, opened) VALUES (10, '��㳡', 1)
INSERT state (code, name, opened) VALUES (11, 'üũ�ƿ����', 1)
INSERT state (code, name, opened) VALUES (12, '���Ϸ�', 0)
INSERT state (code, name, opened) VALUES (13, '��������', 0)
-- end inserting system data

-- begin Shining Lore objects
CREATE TABLE [dbo].[sl_pet_checkin] (
	[pet_seq] [char] (14) NOT NULL ,
	[seq] [smallint] NOT NULL ,
	[account] [varchar] (14) NOT NULL ,
	[operator] [nvarchar] (14) NOT NULL ,
	[checkin_date] [datetime] NOT NULL ,
	[state] [tinyint] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[sl_pet_memo] (
	[pet_seq] [char] (14) NOT NULL ,
	[seq] [smallint] NOT NULL ,
	[write_date] [datetime] NOT NULL ,
	[writer] [nvarchar] (14) NOT NULL ,
	[content] [nvarchar] (255) NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[sl_pet_message] (
	[pet_seq] [char] (14) NOT NULL ,
	[operator] [nvarchar] (14) NOT NULL ,
	[write_date] [datetime] NOT NULL ,
	[message] [nvarchar] (500) NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[sl_petition] (
	[seq] [char] (14) NOT NULL ,
	[category] [tinyint] NOT NULL ,
	[grade] [tinyint] NOT NULL ,
	[world] [tinyint] NOT NULL ,
	[account] [varchar] (14) NOT NULL ,
	[char_id] [nvarchar] (14) NOT NULL ,
	[char_int_id] [int] NOT NULL,
	[flag] [tinyint] NOT NULL ,
	[content] [nvarchar] (255) NOT NULL ,
	[create_date] [datetime] NOT NULL ,
	[state] [tinyint] NOT NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[sl_pet_message] WITH NOCHECK ADD 
	CONSTRAINT [PK_sl_pet_message] PRIMARY KEY  CLUSTERED 
	(
		[pet_seq]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[sl_petition] WITH NOCHECK ADD 
	CONSTRAINT [PK_sl_petition] PRIMARY KEY  CLUSTERED 
	(
		[seq]
	)  ON [PRIMARY] 
GO

 CREATE  CLUSTERED  INDEX [IX_sl_pet_checkin_petition] ON [dbo].[sl_pet_checkin]([pet_seq]) ON [PRIMARY]
GO

 CREATE  CLUSTERED  INDEX [IX_sl_pet_seq_petition] ON [dbo].[sl_pet_memo]([pet_seq]) ON [PRIMARY]
GO

ALTER TABLE [dbo].[sl_pet_checkin] WITH NOCHECK ADD 
	CONSTRAINT [DF_sl_pet_checkin_checkin_date] DEFAULT (getdate()) FOR [checkin_date],
	CONSTRAINT [PK_sl_pet_checkin] PRIMARY KEY  NONCLUSTERED 
	(
		[pet_seq],
		[seq]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[sl_pet_memo] WITH NOCHECK ADD 
	CONSTRAINT [DF_sl_pet_memo_seq] DEFAULT (0) FOR [seq],
	CONSTRAINT [DF_sl_pet_memo_write_date] DEFAULT (getdate()) FOR [write_date],
	CONSTRAINT [PK_sl_pet_memo] PRIMARY KEY  NONCLUSTERED 
	(
		[pet_seq],
		[seq]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[sl_pet_message] WITH NOCHECK ADD 
	CONSTRAINT [DF_sl_pet_message_write_date] DEFAULT (getdate()) FOR [write_date]
GO

ALTER TABLE [dbo].[sl_petition] WITH NOCHECK ADD 
	CONSTRAINT [DF_sl_petition_category] DEFAULT (255) FOR [category],
	CONSTRAINT [DF_sl_petition_grade] DEFAULT (1) FOR [grade],
	CONSTRAINT [DF_sl_petition_flag] DEFAULT (0) FOR [flag],
	CONSTRAINT [DF_sl_petition_create_date] DEFAULT (getdate()) FOR [create_date],
	CONSTRAINT [DF_sl_petition_state] DEFAULT (2) FOR [state]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.sl_InsertPetition 
    @seq CHAR(14), 
    @category TINYINT, 
    @world TINYINT,
    @account VARCHAR(14),
    @char_id NVARCHAR(14),
    @char_int_id INT,
    @content NVARCHAR(255),
    @retval INT OUTPUT
AS
SET NOCOUNT ON
BEGIN TRAN
INSERT sl_petition (seq, category, world, account, char_id, char_int_id, content) VALUES
  (@seq, @category, @world, @account, @char_id, @char_int_id, @content)
IF @@ERROR <> 0 GOTO do_rollback
INSERT open_petition (seq, game, world) VALUES (@seq, 1, @world)
IF @@ERROR <>0 GOTO do_rollback
COMMIT TRAN
SET @retval = 0
RETURN

do_rollback:
ROLLBACK TRAN
SET @retval = 1
RETURN
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.sl_UpdatePetition
    @pet_seq CHAR(14),
    @seq SMALLINT, 
    @grade TINYINT,
    @flag TINYINT,
    @state TINYINT,
    @account VARCHAR(14),
    @char_id NVARCHAR(14),
    @world TINYINT,
    @message NVARCHAR(500),
    @retval INT OUTPUT
AS
SET NOCOUNT ON
DECLARE @opened BIT
SELECT @opened = opened FROM state WHERE code = @state
IF @@ROWCOUNT = 0
BEGIN
    SET @retval = 1
    RETURN
END
BEGIN TRAN
IF @state = 3 OR @state = 6 OR @state = 13
BEGIN
    UPDATE sl_petition SET state = @state WHERE seq = @pet_seq
    IF @@ERROR <> 0 GOTO do_rollback
    IF @state <> 13
    BEGIN
        INSERT sl_pet_checkin (pet_seq, seq, account, operator, state) VALUES
          (@pet_seq, @seq, @account, @char_id, @state)
        IF @@ERROR <> 0 GOTO do_rollback
    END
END
ELSE
BEGIN
    UPDATE sl_petition SET state = @state, grade = @grade, flag = @flag WHERE seq = @pet_seq
    IF @@ERROR <> 0 GOTO do_rollback
    IF @seq IS NOT NULL
    BEGIN
        UPDATE sl_pet_checkin SET state = @state, checkin_date = GETDATE() WHERE pet_seq = @pet_seq AND seq = @seq
        IF @@ERROR <> 0 GOTO do_rollback
    END
    IF @message IS NOT NULL
    BEGIN
        INSERT sl_pet_message (pet_seq, operator, message) VALUES (@pet_seq, @char_id, @message)
        IF @@ERROR <> 0 GOTO do_rollback
    END
END
IF @opened = 0
BEGIN
DELETE open_petition WHERE seq = @pet_seq AND game = 1 AND world = @world
IF @@ERROR <> 0 GOTO do_rollback
END
COMMIT TRAN
SET @retval = 0
RETURN

do_rollback:
ROLLBACK TRAN
SET @retval = 1
RETURN
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
INSERT game_title (code, name, table_prefix, auth_id, email) VALUES (1, 'Shining Lore', 'sl_', 5, 'help@shininglore.co.kr')
INSERT category (game, code, name) VALUES (1, 255, '��Ÿ')
-- end Shining Lore objects

-- begin Lineage2 objects
CREATE TABLE [dbo].[l2_pet_checkin] (
	[pet_seq] [char] (14) NOT NULL ,
	[seq] [smallint] NOT NULL ,
	[account] [varchar] (14) NOT NULL ,
	[operator] [nvarchar] (14) NOT NULL ,
	[checkin_date] [datetime] NOT NULL ,
	[state] [tinyint] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[l2_pet_memo] (
	[pet_seq] [char] (14) NOT NULL ,
	[seq] [smallint] NOT NULL ,
	[write_date] [datetime] NOT NULL ,
	[writer] [nvarchar] (14) NOT NULL ,
	[content] [nvarchar] (255) NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[l2_pet_message] (
	[pet_seq] [char] (14) NOT NULL ,
	[operator] [nvarchar] (14) NOT NULL ,
	[write_date] [datetime] NOT NULL ,
	[message] [nvarchar] (500) NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[l2_petition] (
	[seq] [char] (14) NOT NULL ,
	[category] [tinyint] NOT NULL ,
	[grade] [tinyint] NOT NULL ,
	[world] [tinyint] NOT NULL ,
	[account] [varchar] (14) NOT NULL ,
	[char_id] [nvarchar] (14) NOT NULL ,
	[char_int_id] [int] NOT NULL,
	[flag] [tinyint] NOT NULL ,
	[content] [nvarchar] (255) NOT NULL ,
	[create_date] [datetime] NOT NULL ,
	[state] [tinyint] NOT NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[l2_pet_message] WITH NOCHECK ADD 
	CONSTRAINT [PK_l2_pet_message] PRIMARY KEY  CLUSTERED 
	(
		[pet_seq]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[l2_petition] WITH NOCHECK ADD 
	CONSTRAINT [PK_l2_petition] PRIMARY KEY  CLUSTERED 
	(
		[seq]
	)  ON [PRIMARY] 
GO

 CREATE  CLUSTERED  INDEX [IX_l2_pet_checkin_pet_seq] ON [dbo].[l2_pet_checkin]([pet_seq]) ON [PRIMARY]
GO

 CREATE  CLUSTERED  INDEX [IX_l2_pet_memo_pet_seq] ON [dbo].[l2_pet_memo]([pet_seq]) ON [PRIMARY]
GO

ALTER TABLE [dbo].[l2_pet_checkin] WITH NOCHECK ADD 
	CONSTRAINT [DF_l2_pet_checkin_checkin_date] DEFAULT (getdate()) FOR [checkin_date],
	CONSTRAINT [PK_l2_pet_checkin] PRIMARY KEY  NONCLUSTERED 
	(
		[pet_seq],
		[seq]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[l2_pet_memo] WITH NOCHECK ADD 
	CONSTRAINT [DF_l2_pet_memo_seq] DEFAULT (0) FOR [seq],
	CONSTRAINT [DF_l2_pet_memo_write_date] DEFAULT (getdate()) FOR [write_date],
	CONSTRAINT [PK_l2_pet_memo] PRIMARY KEY  NONCLUSTERED 
	(
		[pet_seq],
		[seq]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[l2_pet_message] WITH NOCHECK ADD 
	CONSTRAINT [DF_l2_pet_message_write_date] DEFAULT (getdate()) FOR [write_date]
GO

ALTER TABLE [dbo].[l2_petition] WITH NOCHECK ADD 
	CONSTRAINT [DF_l2_petition_category] DEFAULT (255) FOR [category],
	CONSTRAINT [DF_l2_petition_grade] DEFAULT (1) FOR [grade],
	CONSTRAINT [DF_l2_petition_flag] DEFAULT (0) FOR [flag],
	CONSTRAINT [DF_l2_petition_create_date] DEFAULT (getdate()) FOR [create_date],
	CONSTRAINT [DF_l2_petition_state] DEFAULT (2) FOR [state]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.l2_InsertPetition 
    @seq CHAR(14), 
    @category TINYINT, 
    @world TINYINT,
    @account VARCHAR(14),
    @char_id NVARCHAR(14),
    @char_int_id INT,
    @content NVARCHAR(255),
    @retval INT OUTPUT
AS
SET NOCOUNT ON
BEGIN TRAN
INSERT l2_petition (seq, category, world, account, char_id, char_int_id, content) VALUES
  (@seq, @category, @world, @account, @char_id, @char_int_id, @content)
IF @@ERROR <> 0 GOTO do_rollback
INSERT open_petition (seq, game, world) VALUES (@seq, 2, @world)
IF @@ERROR <>0 GOTO do_rollback
COMMIT TRAN
SET @retval = 0
RETURN

do_rollback:
ROLLBACK TRAN
SET @retval = 1
RETURN
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.l2_UpdatePetition
    @pet_seq CHAR(14),
    @seq SMALLINT, 
    @grade TINYINT,
    @flag TINYINT,
    @state TINYINT,
    @account VARCHAR(14),
    @char_id NVARCHAR(14),
    @world TINYINT,
    @message NVARCHAR(500),
    @retval INT OUTPUT
AS
SET NOCOUNT ON
DECLARE @opened BIT
SELECT @opened = opened FROM state WHERE code = @state
IF @@ROWCOUNT = 0
BEGIN
    SET @retval = 1
    RETURN
END
BEGIN TRAN
IF @state = 3 OR @state = 6 OR @state = 13
BEGIN
    UPDATE l2_petition SET state = @state WHERE seq = @pet_seq
    IF @@ERROR <> 0 GOTO do_rollback
    IF @state <> 13
    BEGIN
        INSERT l2_pet_checkin (pet_seq, seq, account, operator, state) VALUES
           (@pet_seq, @seq, @account, @char_id, @state)
        IF @@ERROR <> 0 GOTO do_rollback
    END
END
ELSE
BEGIN
    UPDATE l2_petition SET state = @state, grade = @grade, flag = @flag WHERE seq = @pet_seq
    IF @@ERROR <> 0 GOTO do_rollback
    IF @seq IS NOT NULL
    BEGIN
        UPDATE l2_pet_checkin SET state = @state, checkin_date = GETDATE() WHERE pet_seq = @pet_seq AND seq = @seq
        IF @@ERROR <> 0 GOTO do_rollback
    END
    IF @message IS NOT NULL
    BEGIN
        INSERT l2_pet_message (pet_seq, operator, message) VALUES (@pet_seq, @char_id, @message)
        IF @@ERROR <> 0 GOTO do_rollback
    END
END
IF @opened = 0
BEGIN
DELETE open_petition WHERE seq = @pet_seq AND game = 2 AND world = @world
IF @@ERROR <> 0 GOTO do_rollback
END
COMMIT TRAN
SET @retval = 0
RETURN

do_rollback:
ROLLBACK TRAN
SET @retval = 1
RETURN
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

INSERT game_title (code, name, table_prefix, auth_id, email) VALUES (2, 'Lineage2', 'l2_', 4, 'help@lineage2.com')
INSERT category (game, code, name) VALUES (2, 1, 'ĳ���� �̵� �Ұ���')
INSERT category (game, code, name) VALUES (2, 2, '���� ���')
INSERT category (game, code, name) VALUES (2, 3, '���� ����')
INSERT category (game, code, name) VALUES (2, 4, '���, ���� ����')
INSERT category (game, code, name) VALUES (2, 5, '�Ұ��� �̿��� �Ű�')
INSERT category (game, code, name) VALUES (2, 255, '��Ÿ')
-- end Lineage2 objects
