**************************************************************

   Thanks for use terry39's LineageII register system v4.4

                 special thanks for anonymous's L2pass C code

                                            09/22/2004

                                      E-mail  : l2@souq.cn
                                      HomePage: l2.souq.cn

**************************************************************
**************************************************************

edit conn.asp and config.asp that suited for you system.

**************************************************************

