#include "memoryFuncs.h"

static BYTE JMP_HOOK = 0xE9;
static BYTE CALL_HOOK = 0xE8;

static int MR_ZERO = 0;
static int DUMP_SIZE = 0x100;

const char *INI_FILE = "L2AC.ini";
static const char * NewServerWindowName="L2AC revised by smeli 2010";

static BYTE lin2=0x69;

/*
//4D62E3	mov,edx
//L2 Account Creator

//4D3F8C mov edx,
const char *str01="SELECT account FROM lin2db.dbo.user_auth";

//4D477A push
const char *str02="SELECT * FROM lin2db.dbo.user_auth WHERE account = '";

//4D4804 push
const char *str03="UPDATE lin2db.dbo.user_auth SET password = ";

//4D48C5 push
const char *str04="INSERT INTO lin2db.dbo.user_auth VALUES ('";

//4D4957 push
const char *str05="INSERT INTO lin2db.dbo.user_account VALUES ('";

//4D49C8 push
const char *str06="SELECT uid FROM lin2db.dbo.user_account WHERE account = '";

//4D4A33 push
const char *str07="INSERT INTO lin2world.dbo.builder_account VALUES ('";

//4D5450 push
const char *str08="SELECT block_flag,block_flag2 FROM lin2db.dbo.user_account WHERE account = '";

//4D5529 push
const char *str09="SELECT default_builder FROM lin2world.dbo.builder_account WHERE account_name = '";

//4D5769 push
const char *str10="UPDATE lin2world.dbo.builder_account SET default_builder = ";

//4D57D4 push
const char *str11="SELECT uid FROM lin2db.dbo.user_account WHERE account = '";

//4D583F push
const char *str12="INSERT INTO lin2world.dbo.builder_account VALUES ('";

//4D58AF
const char *str13="DELETE FROM lin2world.dbo.builder_account WHERE account_name = '";

//4D592E
const char *str14="UPDATE lin2db.dbo.user_account SET block_flag = ";

*/