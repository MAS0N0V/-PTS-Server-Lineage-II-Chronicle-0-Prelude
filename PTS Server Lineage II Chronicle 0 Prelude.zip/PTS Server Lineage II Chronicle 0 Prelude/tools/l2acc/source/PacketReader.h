
#ifndef _PacketReader_h_
#define _PacketReader_h_

#include "WritterPack.h"


class PacketReader
{
public:
	PacketReader(u8 *packet);//, u32 size);
	~PacketReader();

	u8 ReadC()
	{
		u8 ret = *(u8*)(buffer + (pos));
		pos++;
		return ret;
	}

	u32 ReadD()
	{
		u32 ret = *(u32*)(buffer + (pos));
		pos += 4;
		return ret;
	}

	u16 ReadH()
	{
		u16 ret = *(u16*)(buffer + (pos));
		pos += 2;
		return ret;
	}

	WCHAR *ReadS()
	{
		WCHAR *ret = (WCHAR*)(buffer + (pos));
		pos += (lstrlenW((LPCWSTR)ret) + 1) * 2;
		return ret;
	}

	d64 ReadF()
	{
		d64 ret = *(d64*)(buffer + (pos));
		pos += 8;
		return ret;
	}

	u64 ReadQ()
	{
		u64 ret = *(u64*)(buffer + (pos));
		pos += 8;
		return ret;
	}


	u8 PeekC(u32 position)
	{
		u8 ret = *(u8*)(buffer + (position));
		return ret;
	}

	u32 PeekD(u32 position)
	{
		u32 ret = *(u32*)(buffer + (position));
		return ret;
	}

	u16 PeekH(u32 position)
	{
		u16 ret = *(u16*)(buffer + (position));
		return ret;
	}

	WCHAR *PeekS(u32 position)
	{
		WCHAR *ret = (WCHAR*)(buffer + (position));
		return ret;
	}

	d64 PeekF(u32 position)
	{
		d64 ret = *(d64*)(buffer + (position));
		return ret;
	}

	u64 PeekQ(u32 position)
	{
		u64 ret = *(u64*)(buffer + (position));
		return ret;
	}

	u32 pos;
	u8 *buffer;
};

#endif