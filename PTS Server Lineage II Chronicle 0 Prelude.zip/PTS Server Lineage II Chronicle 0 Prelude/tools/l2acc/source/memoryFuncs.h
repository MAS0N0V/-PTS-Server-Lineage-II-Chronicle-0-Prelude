#include "WritterPack.h"
//#include "Shared.h"


#ifndef _MemoryFuncs_h_
#define _MemoryFuncs_h_

extern "C"
{
	static const BYTE JMP = 0xE9;
	static const BYTE CALL = 0xE8;
	static const BYTE NOP = 0x90;

	void WriteMemory(u32 pAddress, void *pData, BYTE length);
	void WriteMemory64(u32 pAddress, u64 data);
	void WriteMemory32(u32 pAddress, u32 data);
	void WriteMemory16(u32 pAddress, u16 data);
	void WriteMemory8(u32 pAddress, u8 data);
	void WriteHook(BYTE opcode, u32 pAddress, void *pFunction, BYTE bNops);
};

#endif
