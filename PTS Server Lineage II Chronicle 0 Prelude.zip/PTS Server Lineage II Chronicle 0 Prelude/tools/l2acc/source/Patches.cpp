#include "Fixes.h"



void pachches()
{

	WriteMemory32(0x004D62E4,(DWORD)NewServerWindowName);

	BYTE bvalue=(BYTE)CIniFile::GetIntValue("lin2change","Common",INI_FILE);
	if (bvalue>0) lin2=bvalue;

	WriteMemory8(0x004D4051,lin2); //1
	WriteMemory8(0x004D4BEB,lin2); //2
	WriteMemory8(0x004D4C80,lin2); //3
	WriteMemory8(0x004D4D51,lin2); //4
	WriteMemory8(0x004D4DA5,lin2); //5
	WriteMemory8(0x004D4E15,lin2); //6
	WriteMemory8(0x004D4E55,lin2); //7
	WriteMemory8(0x004D5650,lin2); //8
	WriteMemory8(0x004D56DD,lin2); //9
	WriteMemory8(0x004D5A5C,lin2); //10
	WriteMemory8(0x004D5AD5,lin2); //11
	WriteMemory8(0x004D5B15,lin2); //12
	WriteMemory8(0x004D5b69,lin2); //13
	WriteMemory8(0x004D5bb0,lin2); //14



	/*
	WriteMemory32(0x004D3F8D,(DWORD)str01);
	WriteMemory32(0x004D477B,(DWORD)str02);
	WriteMemory32(0x004D4805,(DWORD)str03);
	WriteMemory32(0x004D48C6,(DWORD)str04);
	WriteMemory32(0x004D4958,(DWORD)str05);
	WriteMemory32(0x004D49C9,(DWORD)str06);
	WriteMemory32(0x004D4A34,(DWORD)str07);
	WriteMemory32(0x004D5451,(DWORD)str08);
	WriteMemory32(0x004D552A,(DWORD)str09);
	WriteMemory32(0x004D576A,(DWORD)str10);
	WriteMemory32(0x004D57D5,(DWORD)str11);
	WriteMemory32(0x004D5840,(DWORD)str12);
	WriteMemory32(0x004D58B0,(DWORD)str13);
	WriteMemory32(0x004D592F,(DWORD)str14);
	*/


}


