//--------------------------------------
// Roxas Witer Pack
// used to assemble, disasemble packets
//--------------------------------------

#include "Windows.h"

typedef BYTE u8;
typedef DWORD u32;
typedef WORD u16;
typedef double d64;
typedef __int64	u64;