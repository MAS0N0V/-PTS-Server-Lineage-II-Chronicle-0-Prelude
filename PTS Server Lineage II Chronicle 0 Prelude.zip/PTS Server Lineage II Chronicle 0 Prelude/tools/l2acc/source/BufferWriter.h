
#ifndef _BufferWriter_h_
#define _BufferWriter_h_

#include "WritterPack.h"


class BufferWriter
{
public:
	BufferWriter(u8 *buff);
	~BufferWriter();

	// Increase capacity of the buffer
	void Expand(u32 addBytes);

	// Write byte
	u8 *WriteC(u8 val)
	{
		return Write<u8>(val);
	}

	// Write unsigned integer
	u32 *WriteD(u32 val)
	{
		return Write<u32>(val);
	}
	// Write unicode string
	WCHAR *WriteS(WCHAR *val)
	{
		WCHAR *buffLoc = 0;
		u8 *strPtr = (u8*)val;
		for(u32 i = 0; i < wcslen(val) * 2 + 2; i++)
		{
			if(buffLoc == 0)
				buffLoc = (WCHAR*)Write<u8>(*(strPtr + i));
			else
				Write<u8>(*(strPtr + i));
		}
		return buffLoc;
	}

	// Write unsigned 16 bits integer
	u16 *WriteH(u16 val)
	{
		return Write<u16>(val);
	}

	// Write double
	d64 *WriteF(d64 val)
	{
		return Write<d64>(val);
	}

	// Write unsigned 64 bits integer
	u64 *WriteQ(u64 val)
	{
		return Write<u64>(val);
	}

	// Pointer to beginning of the buffer
	u8 *buffer;
	// size of filled buffer
	u16 size;
protected:
	template <class T>
	T *Write(T val)
	{
		T *retPtr = (T*)_endOfBuffer;
		memcpy(_endOfBuffer, &val, sizeof(T));
		_endOfBuffer += sizeof(T);
		size += sizeof(T);
		return retPtr;
	}
	// Pointer to the end of the buffer
	u8 *_endOfBuffer;
	// Capacity of buffer
	u32 capacity;
};

#endif
