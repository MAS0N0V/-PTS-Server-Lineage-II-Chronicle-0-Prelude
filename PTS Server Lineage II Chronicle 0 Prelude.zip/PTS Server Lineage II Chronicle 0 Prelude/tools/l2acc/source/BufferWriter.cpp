
#include "BufferWriter.h"


BufferWriter::BufferWriter(u8 *buff)
{
	_endOfBuffer = buffer = buff;
	size = 0;
}

BufferWriter::~BufferWriter()
{
	//delete [] buffer;
}
