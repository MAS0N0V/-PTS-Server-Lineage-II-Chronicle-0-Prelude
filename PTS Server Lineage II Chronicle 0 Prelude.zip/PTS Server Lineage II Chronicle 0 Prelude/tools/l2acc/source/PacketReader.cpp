#include "PacketReader.h"


PacketReader::PacketReader(u8 *packet)//, u32 size)
{
	pos = 0;
	buffer = packet;//new u8[size];
	//memcpy(buffer, packet, size);
}

PacketReader::~PacketReader()
{
	//delete [] buffer;
}
