#include "memoryFuncs.h"




#pragma warning(disable: 4309)
#pragma warning(disable: 4311)

DWORD dwProcessID = 0;
HANDLE hProcess = 0;

BOOL SetPrivilege(
	HANDLE hToken,		  // token handle
	LPCTSTR Privilege,	  // Privilege to enable/disable
	BOOL bEnablePrivilege   // TRUE to enable.  FALSE to disable
	)
{
	TOKEN_PRIVILEGES tp;
	LUID luid;
	TOKEN_PRIVILEGES tpPrevious;
	DWORD cbPrevious=sizeof(TOKEN_PRIVILEGES);

	if(!LookupPrivilegeValue( NULL, Privilege, &luid )) return FALSE;

	// 
	// first pass.  get current privilege setting
	// 
	tp.PrivilegeCount		   = 1;
	tp.Privileges[0].Luid	   = luid;
	tp.Privileges[0].Attributes = 0;

	AdjustTokenPrivileges(
			hToken,
			FALSE,
			&tp,
			sizeof(TOKEN_PRIVILEGES),
			&tpPrevious,
			&cbPrevious
			);

	if (GetLastError() != ERROR_SUCCESS) return FALSE;

	// 
	// second pass.  set privilege based on previous setting
	// 
	tpPrevious.PrivilegeCount	   = 1;
	tpPrevious.Privileges[0].Luid   = luid;

	if(bEnablePrivilege) {
		tpPrevious.Privileges[0].Attributes |= (SE_PRIVILEGE_ENABLED);
	}
	else {
		tpPrevious.Privileges[0].Attributes ^= (SE_PRIVILEGE_ENABLED &
			tpPrevious.Privileges[0].Attributes);
	}

	AdjustTokenPrivileges(
			hToken,
			FALSE,
			&tpPrevious,
			cbPrevious,
			NULL,
			NULL
			);

	if (GetLastError() != ERROR_SUCCESS) return FALSE;

	return TRUE;
}

void WriteMemory(u32 pAddress, void *pData, BYTE length)
{
	if(hProcess == 0)
	{
		HANDLE hToken;
		if(!OpenThreadToken(GetCurrentThread(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, FALSE, &hToken))
		{
			if (GetLastError() == ERROR_NO_TOKEN)
			{
				if (!ImpersonateSelf(SecurityImpersonation))
					return;	// error!

				if(!OpenThreadToken(GetCurrentThread(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, FALSE, &hToken))
					return;	// error!	
			 }
			else
				return;	// error!
		 }

		// enable SeDebugPrivilege
		if(!SetPrivilege(hToken, SE_DEBUG_NAME, TRUE))
		{
			// close token handle
			CloseHandle(hToken);

			// indicate failure
			return;
		}

		dwProcessID = GetCurrentProcessId();
		hProcess = OpenProcess(PROCESS_ALL_ACCESS | PROCESS_VM_READ | PROCESS_VM_WRITE, false, dwProcessID);

		if (!hProcess)
		{
			DWORD err = GetLastError();
			char error[255];
			//sprintf_s(error, 255, "Unable to open L2Server's Process! Please restart the server. Error code: %d", err);
			MessageBox(NULL, (LPCWSTR)error, (LPCWSTR)"Error. Unable to open L2Server's Process", MB_OK);
			ExitProcess(1);
		}
	}

	DWORD dwOldProtect = NULL;
	SIZE_T bWritten = NULL;
	if (!VirtualProtect((LPVOID)(pAddress), length, PAGE_EXECUTE_READWRITE, &dwOldProtect))
	{
		//error
	}

	if (!WriteProcessMemory(hProcess, (LPVOID)(pAddress), (LPCVOID)pData, length, &bWritten))
	{
		//error
		ExitProcess(1);
		return;
	}

	if (!VirtualProtect((LPVOID)(pAddress), length, dwOldProtect, &dwOldProtect))
	{
		//error
	}
}

void WriteMemory64(u32 pAddress, u64 data)
{
	WriteMemory(pAddress, &data, 8);
}
void WriteMemory32(u32 pAddress, u32 data)
{
	WriteMemory(pAddress, &data, 4);
}
void WriteMemory16(u32 pAddress, u16 data)
{
	WriteMemory(pAddress, &data, 2);
}
void WriteMemory8(u32 pAddress, u8 data)
{
	WriteMemory(pAddress, &data, 1);
}
void WriteHook(BYTE opcode, u32 pAddress, void *pFunction, BYTE bNops)
{
	WriteMemory(pAddress, &opcode, 1);
	DWORD pFuncAddress = (DWORD)pFunction - (DWORD)(pAddress+5);
	WriteMemory((pAddress + 1), &pFuncAddress, sizeof(pFuncAddress));
	while (bNops != 0)
	{
		int i = 5;
		WriteMemory((pAddress + i), (void*)&NOP, 1);
		++i;
		--bNops;
	}
}

