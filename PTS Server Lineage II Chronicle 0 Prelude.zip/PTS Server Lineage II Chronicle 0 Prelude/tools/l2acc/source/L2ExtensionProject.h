#ifndef _WINDOWS_
	#include <windows.h>
#endif

//DLL Main
__declspec( dllexport ) BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpReserved);


void pachches();
