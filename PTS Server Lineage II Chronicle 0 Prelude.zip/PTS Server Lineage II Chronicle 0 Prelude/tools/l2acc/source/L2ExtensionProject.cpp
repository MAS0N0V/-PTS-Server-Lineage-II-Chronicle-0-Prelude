#include "L2ExtensionProject.h"
#include "memoryFuncs.h"
//#include "Windows.h"


__declspec( dllexport ) BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpReserved) 
{


	//our DLL state switch
	switch( fdwReason )
	{
		case DLL_PROCESS_ATTACH:
		{

			pachches(); //install our exe file patches (patches CPP)

			break;
		}
		case DLL_THREAD_ATTACH:
			break;       
		case DLL_THREAD_DETACH:
			break;
		case DLL_PROCESS_DETACH:


			//Destroy our Critical Section
			//DeleteCriticalSection(&cs);


			break;   
	}  
	return TRUE; 
}





