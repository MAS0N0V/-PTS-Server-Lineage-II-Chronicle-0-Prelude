smeli update 2010

l2 account creator using hardcoded databases
lin2db, lin2world

i was able only add ablity to change letter 'i' (105)
to other symbol via l2ac.ini file